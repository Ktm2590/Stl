                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:983995
HackRF One PortaPack Case by ne1 is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This is my first attempt to make a Case for the Portapack. I had some trouble with the support for the Display hole, so i made one with own support structure - because the build in doesn't work for me.  

2015-08-26 UPDATE: Changed a few holes a little bit and I forgot the MicroSD Slot. Now fixed  

2015-08-27 UPDATE: I'm not happy with my approach to combine those two parts. As you can see in the second picture, there is a little gap. I will think about it to avoid this gap - any suggestions? 

# Instructions

Print both from the side where the connections are. I had problems with warping when the layers are too thin (0.08) so I print it with a layer thickness of 0.15, but this could be caused by my printer.   
You need a few longer screws. I don't know exactly what size, but when i updated it, when its clear.